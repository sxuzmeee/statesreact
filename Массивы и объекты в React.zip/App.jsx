import './App.css';
import { useState } from 'react';



// function App() {


  
//   const [notes, setNotes] = useState([6, 4, 9, 8, 5, 3, 1, 2])

//   const result = notes.map((note, index) => {
//     return (
//       <div key={index}>
//         <p>{note}</p>
//         <button onClick={() => delItem(index)}>Delete element</button>
//         <button onClick={() => changeItem(index)}>Change element</button>
//       </div>
//     )
//   })

//   function addItem(){
//     // let copy = Object.assign([], notes);
//     // copy.push(7);
//     // setNotes(copy);

//     setNotes([...notes, value])
//   }

//   function changeItem(index){
//     // let copy = Object.assign([], notes);
//     // copy[index] = 123456;
//     // setNotes(copy);
//     setNotes([...notes.slice(0, index), 12346578, ...notes.slice(index+1)])
//   }

//   function delItem(index){
//     // let copy = Object.assign([], notes)
//     // copy.splice(0, index)
//     // setNotes(copy)
//     setNotes([...notes.slice(0, index), ...notes.slice(index +1)]);
//   }

//   function sortNotes(){
//     let copy = [...notes]
//     copy.sort();
//     setNotes(copy);

//   }

//   function summ(){
//     let summa = 0;
//     notes.forEach(note => summa += +note);
//     return summa;
//   }

//   let [value, setValue] = useState('')
 
//   return (
//     <div className='App'>
//       {result}
//       <input type="text" value={value} onChange={(event) => setValue(event.target.value)}/>
//       <button onClick={addItem}>Add element</button>
//       <br />

//       <button onClick={sortNotes}>Sort elements</button>
//       <br />
//       <p>{summ()}</p>
//     </div>
//   );
// }

// function App() {
//   const [todos, setTodos] = useState(['Wake up', 'Learn Book', 'Work']);
//   const [editNum, setEditNum] = useState(null)
//   const [value, setValue] = useState('');

//   const printTodos = todos.map((todo, index) => {
//     return (
//       <div key={index} className='todo__block'>
//         <p className='todo__item' onClick={() => setEditNum(index)}>{todo}</p>
//         <button onClick={() => delTodo(index)}>Delete</button>
//       </div>
//     );
//   });

//   function changeItem(event){
//     setTodos([...todos.slice(0, editNum), event.target.value, ...todos.slice(editNum+1)])
//   }

//   function delTodo(index){
//     setTodos([...todos.slice(0, index), ...todos.slice(index+1)])
//   }

//   function stopEdit(){
//     setEditNum(null);
//   }

//   function changeValue(event){
//     setValue(event.target.value);
//   }

//   function addTodo(){
//     setTodos([...todos, value])
//   }


//   let input;
//   if (editNum !== null){
//     input = (
//       <input type='text' className='todo__item_new' value={todos[editNum]} onChange={changeItem} onBlur={stopEdit}></input>
//     );
//   } else {
//     input = (
//       <input type='text' value={value} onChange={changeValue} onBlur={addTodo}></input>
//     );
//   }

//   return (
//     <div>
//       {printTodos}
//       {input    }  
//     </div>
//   )
// }

// function App() {
//   const [obj, setObj] = useState({
//     prop1: 'value1',
//     prop2: 'value2',
//     prop3: 'value3',
//   })

//   function changeObj(){
//     // let copy = Object.assign({}, obj);
//     // copy.prop1 = 12443
//     // setObj(copy)
//     setObj({...obj, ...{prop1:'sfdfdmg'}})
//   }


//   function changeHandler(){
//     // let copy = Object.assign({}, obj);
//     // copy[prop] = event.target.value;
//     // setObj(copy)
//     setObj({...obj,...{[prop]: event.target.value}})
//   }
  
//   return (
//     <div>
//       <p>{obj.prop1}</p>
//       <p>{obj.prop2}</p>
//       <p>{obj.prop3}</p>
//       <input type="text" value={value} onChange={(event) => setValue(event.target.value)}/>
//       <input type="text" value={obj.prop2} onChange={(event) => changeHandler('prop2',event)}/>
//       <button onClick={changeObj}>change</button>
//     </div>
//   )
// }

// function App() {
//   const [products, setProducts] = useState([
//     {id: 1, name: "Продукт 1", description: "Описание продукта 1", price: 10 }, 
//     {id: 2,  name: "Продукт 2", description: "Описание продукта 2", price: 20 }, 
//     {id: 3,  name: "Продукт 3", description: "Описание продукта 3", price: 15 }, 
//     {id: 4,  name: "Продукт 4", description: "Описание продукта 4", price: 25 }, 
//     {id: 5,  name: "Продукт 5", description: "Описание продукта 5", price: 12 }, 
//     {id: 6,  name: "Продукт 6", description: "Описание продукта 6", price: 18 }, 
//     {id: 7,  name: "Продукт 7", description: "Описание продукта 7", price: 30 }, 
//     {id: 8,  name: "Продукт 8", description: "Описание продукта 8", price: 22 }, 
//     {id: 9,  name: "Продукт 9", description: "Описание продукта 9", price: 17 }, 
//     {id: 10,  name: "Продукт 10", description: "Описание продукта 10", price: 14 }, 
//     {id: 11,  name: "Продукт 11", description: "Описание продукта 11", price: 16 }, 
//     {id: 12,  name: "Продукт 12", description: "Описание продукта 12", price: 21 }, 
//     {id: 13,  name: "Продукт 13", description: "Описание продукта 13", price: 19 }, 
//     {id: 14,  name: "Продукт 14", description: "Описание продукта 14", price: 24 }, 
//     {id: 15,  name: "Продукт 15", description: "Описание продукта 15", price: 23 } 
//   ]);

//   const printProd = products.map(product => {
//     return (
//       <div key={product.id}>
//         <h4>{product.title}</h4>
//         <p>{product.description}</p>
//         <p>{product.price}</p>
//         <button onClick={() => delProduct(product.id)}>Delete</button>
//         <button onClick={() => changeProd(product.id)}>change product</button>
//       </div>
//     )
//   })

//   function changeProd(id){
//     let newProd ={
//       id:id,
//       title: "product change",
//       description: 'Description change',
//       price: 1080
//     };
//     setProducts(products.map(product => {
//       if (product.id === id){
//         return newProd
//       } else {
//         return product
//       }
//     }))
//   }

//   function addProd(){

//   }


//   function delProduct(id){
//     setProducts(products.filter(product => {
//       if (product.id !== id){
//         return product
//       }
//     }))
//   }

//   return (
//     <div>
//       {printProd}
//     </div>
//   )
// }






function App() {
  // Задание 1
  const [notes1, setNotes1] = useState([6, 4, 9, 8, 5, 3, 1, 2]);

  const addItem1 = () => {
    setNotes1([...notes1, parseInt(value)]);
    setValue('');
  };

  const reverseNotes1 = () => {
    setNotes1([...notes1.reverse()]);
  };

  const delItem1 = (index) => {
    setNotes1([...notes1.slice(0, index), ...notes1.slice(index + 1)]);
  };

  const changeItem1 = (index) => {
    setNotes1([...notes1.slice(0, index), 12346578, ...notes1.slice(index + 1)]);
  };

  // Задание 2
  const [notes2, setNotes2] = useState(['a', 'b', 'c', 'd', 'e']);
  const [value, setValue] = useState('');

  const addNote2 = () => {
    if (value.trim() !== '') {
      setNotes2([...notes2, value]);
      setValue('');
    }
  };

  const deleteNote2 = (index) => {
    setNotes2([...notes2.slice(0, index), ...notes2.slice(index + 1)]);
  };

  const result2 = notes2.map((note, index) => {
    return (
      <div key={index}>
        <ul>
          <li>{note}</li>
          <button onClick={() => deleteNote2(index)}>Delete</button>
        </ul>
      </div>
    );
  });

  // Задание 3
  const [notes3, setNotes3] = useState([1, 2, 3, 4, 5, 6, 7, 8, 9]);
  const [editedNotes, setEditedNotes] = useState([...notes3]);
  const [average, setAverage] = useState(0);

  const calculateAverage = (notes) => {
    const sum = notes.reduce((acc, curr) => acc + curr, 0);
    return notes.length > 0 ? sum / notes.length : 0;
  };

  const handleInputChange = (index, value) => {
    const newNotes = [...editedNotes];
    newNotes[index] = parseInt(value) || 0;
    setEditedNotes(newNotes);
    setAverage(calculateAverage(newNotes));
  };

  const renderInputs = () => {
    return editedNotes.map((note, index) => (
      <input
        key={index}
        type="number"
        value={note}
        onChange={(event) => handleInputChange(index, event.target.value)}
      />
    ));
  };

  // Задание 4
  const [notes4, setNotes4] = useState(['a', 'b', 'c', 'd', 'e']);
  const [editString, setEditString] = useState('');

  const changeItem4 = (event) => {
    setNotes4([...notes4.slice(0, editString), event.target.value, ...notes4.slice(editString + 1)]);
  };

  const clearInput4 = () => {
    setEditString('');
  };

  const result4 = notes4.map((note, index) => {
    return (
      <div key={index}>
        <ul onClick={() => setEditString(index)}>
          <li>{note}</li>
        </ul>
      </div>
    );
  });

  return (
    <div className='App'>
      {/* Задание 1 */}
      {notes1.map((note, index) => (
        <div key={index}>
          <p>{note}</p>
          <button onClick={() => delItem1(index)}>Удалить Элемент</button>
          <button onClick={() => changeItem1(index)}>Изменить Элемент</button>
        </div>
      ))}
      <button onClick={reverseNotes1}>Перевернуть</button>

      {/* Задание 2*/}
      {result2}
      <input type="text" value={value} onChange={(event) => setValue(event.target.value)} />
      <button onClick={addNote2}>Добавить Элемент</button>

      {/* Задание 3 */}
      <div>
        <p>Среднее арифметическое: {average.toFixed(2)}</p>
        {renderInputs()}
      </div>

      {/* Задание 4 */}
      {result4}
      <input value={editString ? notes4[editString] : ''} onChange={changeItem4} onBlur={clearInput4}></input>
    </div>
  );
}

// Задание 5

function App() {
  // Первый подход: 
  const [notes1, setNotes1] = useState(['a', 'b', 'c', 'd', 'e']);
  const [editIndex1, setEditIndex1] = useState(null);
  const [value1, setValue1] = useState('');

  // Второй подход: 
  const [notes2, setNotes2] = useState(['a', 'b', 'c', 'd', 'e']);
  const [editIndex2, setEditIndex2] = useState(null);
  const [value2, setValue2] = useState('');

  // Третий подход:
  const [notes3, setNotes3] = useState(['a', 'b', 'c', 'd', 'e']);
  const [editValue3, setEditValue3] = useState('');

  const handleEdit1 = (index) => {
    setEditIndex1(index);
    setValue1(notes1[index]);
  };

  const handleChange1 = (event) => {
    setValue1(event.target.value);
  };

  const handleBlur1 = () => {
    if (editIndex1 !== null) {
      const newNotes = [...notes1];
      newNotes[editIndex1] = value1;
      setNotes1(newNotes);
      setEditIndex1(null);
      setValue1('');
    }
  };

  const handleAdd1 = () => {
    if (value1.trim() !== '') {
      setNotes1([...notes1, value1]);
      setValue1('');
    }
  };

  const handleEdit2 = (index) => {
    setEditIndex2(index);
    setValue2(notes2[index]);
  };

  const handleChange2 = (event) => {
    setValue2(event.target.value);
  };

  const handleBlur2 = () => {
    if (editIndex2 !== null) {
      const newNotes = [...notes2];
      newNotes[editIndex2] = value2;
      setNotes2(newNotes);
      setEditIndex2(null);
      setValue2('');
    }
  };

  const handleAdd2 = () => {
    if (value2.trim() !== '') {
      setNotes2([...notes2, value2]);
      setValue2('');
    }
  };

  const handleEdit3 = (index) => {
    setEditValue3(notes3[index]);
    setNotes3((prevNotes) => {
      const newNotes = [...prevNotes];
      newNotes[index] = '';
      return newNotes;
    });
  };

  const handleChange3 = (event) => {
    setEditValue3(event.target.value);
  };

  const handleBlur3 = (index) => {
    if (editValue3.trim() !== '') {
      const newNotes = [...notes3];
      newNotes[index] = editValue3;
      setNotes3(newNotes);
      setEditValue3('');
    }
  };

  const handleAdd3 = () => {
    if (editValue3.trim() !== '') {
      setNotes3([...notes3, editValue3]);
      setEditValue3('');
    }
  };

  return (
    <div>
      <h2>Первый подход</h2>
      <ul>
        {notes1.map((note, index) => (
          <li key={index} onClick={() => handleEdit1(index)}>
            {index === editIndex1 ? (
              <input
                type="text"
                value={value1}
                onChange={handleChange1}
                onBlur={handleBlur1}
                autoFocus
              />
            ) : (
              note
            )}
          </li>
        ))}
      </ul>
      <input
        type="text"
        value={value1}
        onChange={handleChange1}
        onBlur={handleAdd1}
        placeholder="Добавить новый элемент"
      />

      <h2>Второй подход</h2>
      {notes2.map((note, index) => (
        <p key={index} onClick={() => handleEdit2(index)}>
          {index === editIndex2 ? (
            <input
              type="text"
              value={value2}
              onChange={handleChange2}
              onBlur={handleBlur2}
              autoFocus
            />
          ) : (
            note
          )}
        </p>
      ))}
      <input
        type="text"
        value={value2}
        onChange={handleChange2}
        onBlur={handleAdd2}
        placeholder="Добавить новый элемент"
      />

      <h2>Третий подход</h2>
      <ul>
        {notes3.map((note, index) => (
          <li key={index} onClick={() => handleEdit3(index)}>
            {editValue3 && index === notes3.length - 1 ? (
              <input
                type="text"
                value={editValue3}
                onChange={handleChange3}
                onBlur={() => handleBlur3(index)}
                autoFocus
              />
            ) : (
              note
            )}
          </li>
        ))}
      </ul>
      <input
        type="text"
        value={editValue3}
        onChange={handleChange3}
        onBlur={handleAdd3}
        placeholder="Добавить новый элемент"
      />
    </div>
  );
}

// Объекты. Практическое задание

const initProds = [
  { id: 1, name: 'product1', category: 'category1', price: 100 },
  { id: 2, name: 'product2', category: 'category2', price: 200 },
  { id: 3, name: 'product3', category: 'category3', price: 300 },
];

function App() {
  const [prods, setProds] = useState(initProds);
  const [editId, setEditId] = useState(null);
  const [newProd, setNewProd] = useState({ id: '', name: '', category: '', price: '' });

  function changeProp(prop) {
    return () => {
      setNewProd({ ...newProd, [prop]: newProd[prop] === '' ? 'New Value' : '' });
    };
  }

  function handleDelete(id) {
    setProds(prods.filter((prod) => prod.id !== id));
  }

  function handleChange(event, prop) {
    setNewProd({ ...newProd, [prop]: event.target.value });
  }

  function handleAddProd() {
    setProds([...prods, newProd]);
    setNewProd({ id: '', name: '', category: '', pricev: '' });
  }

  function handleEdit(id) {
    setEditId(id);
    const editProd = prods.find((prod) => prod.id === id);
    setNewProd({ ...editProd });
  }

  function handleSaveEdit() {
    setProds(prods.map((prod) => (prod.id === editId ? newProd : prod)));
    setEditId(null);
    setNewProd({ id: '', name: '', category: '', price: '' });
  }

  const tableRows = prods.map((prod) => (
    <tr key={prod.id}>
      <td>{prod.id}</td>
      <td>{prod.name}</td>
      <td>{prod.category}</td>
      <td>{prod.price}</td>
      <td>
        <button onClick={() => handleDelete(prod.id)}>Удалить</button>
        <button onClick={() => handleEdit(prod.id)}>Изменить</button>
      </td>
    </tr>
  ));

  return (
    <div>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>{tableRows}</tbody>
      </table>
      <div>
        <input value={newProd.id} onChange={(e) => handleChange(e, 'id')} placeholder="ID" />
        <input value={newProd.name} onChange={(e) => handleChange(e, 'name')} placeholder="Name" />
        <input value={newProd.category} onChange={(e) => handleChange(e, 'category')} placeholder="Category" />
        <input value={newProd.price} onChange={(e) => handleChange(e, 'price')} placeholder="Price" />
        {editId ? (
          <button onClick={handleSaveEdit}>Сохранить</button>
        ) : (
          <button onClick={handleAddProd}>Добавить продукт</button>
        )}
      </div>
      <div>
        <button onClick={changeProp('name')}>Изменить название</button>
        <button onClick={changeProp('category')}>Изменить категорию</button>
        <button onClick={changeProp('price')}>Изменить цену</button>
      </div>
    </div>
  );
}

export default App;
